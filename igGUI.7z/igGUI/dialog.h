#ifndef DIALOG_H
#define DIALOG_H

#include <QDialog>
#include <QAbstractTableModel>
#include<QTableView>
#include <QGroupBox>
#include<QGridLayout>
#include<QTabWidget>
#include <QComboBox>
namespace Ui {
class Dialog;
}

class Dialog : public QDialog
{
    Q_OBJECT

public:
    explicit Dialog(QWidget *parent = 0);
    ~Dialog();

private:
    Ui::Dialog *ui;
    QTableView *tableView;
    QGroupBox * groupBox;
    QTabWidget *tabWidget;


};
class Standard: public QWidget{
    Q_OBJECT
public:
    Standard(QWidget *parent=0);
};
class CAN: public QWidget{
    Q_OBJECT
public:
    CAN(QWidget *parent=0);
};


#endif // DIALOG_H

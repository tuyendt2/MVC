#include "dialog.h"
#include "ui_dialog.h"
#include <QMenu>
#include<QPushButton>

Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog)
{
    ui->setupUi(this);
    QVBoxLayout *main_layout = new QVBoxLayout;
    tabWidget = new QTabWidget;
    tabWidget->addTab(new Standard,tr("Standard"));
    tabWidget->addTab(new CAN,tr("CAN"));
    QHBoxLayout *boxLayout = new QHBoxLayout;
    QMenu *New = new QMenu;
    QAction * CAN_message = new QAction(tr("CAN message"),)
    New->addAction(tr("CAN message"));
    QMenu *defaultMode= new QMenu;
    defaultMode->addAction
    QPushButton *clone = new QPushButton;
    clone.


    boxLayout->addWidget(New);

    setLayout(main_layout);
}

Dialog::~Dialog()
{
    delete ui;
}

Standard::Standard(QWidget *parent)
{

}

CAN::CAN(QWidget *parent)
{

}
